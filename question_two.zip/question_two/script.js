document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("signup-form");
    const detailsContainer = document.getElementById("signup-details");

    form.addEventListener("submit", function(event) {
        event.preventDefault();

        const firstName = form['first-name'].value;
        const lastName = form['last-name'].value;

        detailsContainer.innerHTML = `<p>Congratulations ${firstName} ${lastName}, you are now signed up!</p>`;

        form.reset();
    });
});
